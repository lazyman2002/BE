package hadoop;

public class KafkaService {
}
