package hadoop;

public class SparkService {
}
