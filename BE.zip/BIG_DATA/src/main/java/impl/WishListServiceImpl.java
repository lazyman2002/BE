package impl;

import com.google.protobuf.BoolValue;
import com.google.protobuf.Int32Value;
import hadoop.HbaseService;
import io.grpc.stub.StreamObserver;
import proto.ServerClient;
import proto.WishListServiceGrpc;

import java.util.List;

public class WishListServiceImpl extends WishListServiceGrpc.WishListServiceImplBase {
    @Override
    public void recommendation(Int32Value request, StreamObserver<Int32Value> responseObserver) {
        System.out.println("recommendation");
        HbaseService hbaseService = new HbaseService();
        try {
            List<Integer> ans = hbaseService.findRecommend(request.getValue());
            for(Integer ID: ans){
                responseObserver.onNext(Int32Value.newBuilder().setValue(ID).build());
            }
            responseObserver.onCompleted();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void updateJobVector(ServerClient.JobRequestFullInfo request, StreamObserver<BoolValue> responseObserver) {
        System.out.println("updateJobVector");
        HbaseService hbaseService = new HbaseService();
        try {
            hbaseService.updateJob(request);
            responseObserver.onNext(BoolValue.newBuilder().setValue(true).build());
            responseObserver.onCompleted();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
