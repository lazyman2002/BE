package org.app;

import hadoop.RecommendationService;
import hadoop.TextVectorizer;
import impl.WishListServiceImpl;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import org.connectConfig.ENVDockers;

import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException{
        ScheduledExecutorService shedule = Executors.newScheduledThreadPool(1);
        shedule.scheduleAtFixedRate(new ParquetUpdate(), 10, 60, TimeUnit.SECONDS);
        Server server = ServerBuilder.forPort(ENVDockers.gRPC_port)
                .addService(new WishListServiceImpl())
                .build();
        server.start();
        server.awaitTermination();
        TextVectorizer.getInstance().stop();
        RecommendationService.getInstance().stop();

//        String hdfsUri = "hdfs://master1:9000"; // sửa theo URI của cluster bạn
//        String directory = "/user/testfolder";
//        String filePath = directory + "/example.txt";
//
//        try {
//            // Load config từ core-site.xml và hdfs-site.xml nếu cần
//            Configuration conf = new Configuration();
//            conf.set("fs.defaultFS", hdfsUri);
//
//            // Lấy hệ thống file từ URI
//            FileSystem fs = FileSystem.get(new URI(hdfsUri), conf);
//
//            // Tạo thư mục
//            Path dirPath = new Path(directory);
//            if (!fs.exists(dirPath)) {
//                fs.mkdirs(dirPath);
//                System.out.println("Đã tạo thư mục: " + directory);
//            } else {
//                System.out.println("Thư mục đã tồn tại: " + directory);
//            }
//
//            // Tạo file và ghi nội dung
//            Path txtFilePath = new Path(filePath);
//            try (OutputStream os = fs.create(txtFilePath);
//                 BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"))) {
//                writer.write("Xin chào HDFS!");
//                System.out.println("Đã tạo file và ghi dữ liệu: " + filePath);
//            }
//
//            fs.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

    }
}