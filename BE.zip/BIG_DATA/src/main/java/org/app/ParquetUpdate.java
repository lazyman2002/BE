package org.app;

import hadoop.HbaseService;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.avro.AvroParquetWriter;
import org.apache.parquet.hadoop.ParquetWriter;
import org.apache.parquet.hadoop.metadata.CompressionCodecName;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ParquetUpdate implements Runnable{
    @Override
    public void run(){
        HbaseService hbaseService = new HbaseService();
        try {
            List<HbaseService.LocalJob> jobList = hbaseService.readVectorJobs();
            System.out.println("asd");
            String schemaString = "{"
                    + "\"type\":\"record\","
                    + "\"name\":\"LocalJob\","
                    + "\"fields\":["
                    + "  {\"name\":\"jobID\", \"type\":\"int\"},"
                    + "  {\"name\":\"vector\", \"type\":{\"type\":\"array\", \"items\":\"double\"}}"
                    + "]}";

            Schema schema = new Schema.Parser().parse(schemaString);

            System.out.println("config");
            jobList.forEach(System.out::println);
            Configuration conf = hbaseService.getConfig();
            Path outputPath = new Path("hdfs://master1:9000/user/WBAC/user/jobs.parquet");

            FileSystem fs = FileSystem.get(conf);
            if (fs.exists(outputPath)) {
                System.out.println("File exists, deleting...");
                fs.delete(outputPath, true);
            }
            System.out.println("connecting");
            try (ParquetWriter<GenericRecord> writer = AvroParquetWriter.<GenericRecord>builder(outputPath)
                    .withSchema(schema)
                    .withConf(conf)
                    .withCompressionCodec(CompressionCodecName.SNAPPY)
                    .build()) {
                System.out.println("connected");
                System.out.println(jobList);
                for (HbaseService.LocalJob job : jobList) {
                    GenericRecord record = new GenericData.Record(schema);
                    record.put("jobID", job.getJobID());

                    double[] doubleArr = job.getVector().toArray();
                    List<Double> doubleList = new ArrayList<>(doubleArr.length);
                    for (double d : doubleArr) {
                        doubleList.add(d);
                    }
                    record.put("vector", doubleList);
                    writer.write(record);
                }
                System.out.println("saved");
            }
            finally {
                try {
                    fs.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
