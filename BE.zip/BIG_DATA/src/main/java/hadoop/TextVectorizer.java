package hadoop;

import org.apache.spark.ml.feature.*;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import java.util.Arrays;

public class TextVectorizer {
    private static TextVectorizer instance;
    private final SparkSession spark;

    private TextVectorizer() {
        this.spark = SparkSession.builder()
                .appName("Text Vectorizer")
                .master("local[*]")
                .getOrCreate();
    }

    public static TextVectorizer getInstance() {
        if (instance == null) {
            synchronized (TextVectorizer.class) {
                if (instance == null) instance = new TextVectorizer();
            }
        }
        return instance;
    }

    public Vector vectorize(String text, String id) {
        System.out.println("vectorize");
        Dataset<Row> data = spark.createDataFrame(Arrays.asList(
                new LocalText(id, text)
        ), LocalText.class);
        System.out.println("dataset");

        Tokenizer tokenizer = new Tokenizer().setInputCol("text").setOutputCol("words");
        StopWordsRemover remover = new StopWordsRemover().setInputCol("words").setOutputCol("filtered");
        HashingTF hashingTF = new HashingTF().setInputCol("filtered").setOutputCol("rawFeatures").setNumFeatures(100);
        IDF idf = new IDF().setInputCol("rawFeatures").setOutputCol("features");
        System.out.println("create matrix");

        Dataset<Row> words = tokenizer.transform(data);
        Dataset<Row> filtered = remover.transform(words);
        Dataset<Row> tf = hashingTF.transform(filtered);
        IDFModel model = idf.fit(tf);
        Dataset<Row> rescaled = model.transform(tf);
        System.out.println("done fitting");

        return rescaled.select("features").first().getAs("features");
    }

    public void stop() {
        spark.stop();
    }

    public class LocalText implements java.io.Serializable {
        private String id;
        private String text;

        public LocalText() {}
        public LocalText(String id, String text) {
            this.id = id;
            this.text = text;
        }

        public String getId() {
            return id;
        }
        public String getText() {
            return text;
        }


    }
}