package hadoop;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.connectConfig.HikariDataSource;
import org.model.*;
import proto.ServerClient;

import java.sql.*;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.io.*;

public class HbaseService {
    private static final String TABLE_CV = "CVs";
    private static final String TABLE_JOB = "Jobs";
    private static final String COLUMN_FAMILY = "vector";

    private Configuration config;
    public HbaseService(){
        config = HBaseConfiguration.create();
        config.set("hbase.zookeeper.quorum", "172.18.0.7");
        config.set("hbase.zookeeper.property.clientPort", "2181");
        config.set("fs.defaultFS", "hdfs://master1:9000");
    }

    public Configuration getConfig() {
        return config;
    }

    public void updateJob(ServerClient.JobRequestFullInfo request) throws Exception{
        System.out.println("updateJob");
        try (org.apache.hadoop.hbase.client.Connection connection = ConnectionFactory.createConnection(config);
            Table table = connection.getTable(TableName.valueOf(TABLE_JOB))) {

            StringBuilder sb = new StringBuilder();
            sb.append(request.getJobTitle()).append(" ");
            sb.append(request.getJobField()).append(" ");
            sb.append(request.getJobDescription()).append(" ");
            sb.append(request.getJobRequirement()).append(" ");

            String fullText = sb.toString();
            System.out.println(fullText);
            TextVectorizer textVectorizer = TextVectorizer.getInstance();
            Vector vector = textVectorizer.vectorize(fullText, String.valueOf(request.getJobID()));
            System.out.println(vector.toString());
            byte[] vectorBytes = serializeVector(vector);
            System.out.println("serial");
            Put put = new Put(Bytes.toBytes(request.getJobID()));
            put.addColumn(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("vector"), vectorBytes);
            String deadlineStr = request.getDeadlineDate().toString();
            put.addColumn(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("deadline"), Bytes.toBytes(deadlineStr));
            table.put(put);
            System.out.println("save");
        }
    }


    public List<Integer> findRecommend(Integer CVID) throws Exception{
        System.out.println("findRecommend");
        System.out.println("CVID" + CVID);
        Timestamp sqlTimestamp = SQLupdateTimestamp(CVID);
        long hbaseTimestamp = HbaseupdateTimestamp(CVID);
        long sqlTime = sqlTimestamp.getTime();
        System.out.println("timestamped");
        Vector CVvector;
        System.out.println(hbaseTimestamp);
        System.out.println(sqlTime);
        if (hbaseTimestamp < sqlTime) {
            CVvector = updateVectorCV(CVID);
        }
        else {
            CVvector = readVectorCV(CVID);
        }
        System.out.println("vectored");
        RecommendationService recommendationService = RecommendationService.getInstance();
        return recommendationService.findTop5JobsForCV(CVvector, "output/jobs.parquet");
    }

    public List<LocalJob> readVectorJobs() throws Exception{
        String todayStr = LocalDate.now().toString();
        List<LocalJob> jobVectors = new ArrayList<>();
        try (org.apache.hadoop.hbase.client.Connection connection = ConnectionFactory.createConnection(config);
             Table table = connection.getTable(TableName.valueOf(TABLE_JOB))) {
            Scan scan = new Scan();
            scan.addColumn(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("vector"));
            scan.addColumn(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("deadline"));

            try (ResultScanner scanner = table.getScanner(scan)) {
                for (Result result : scanner) {
                    byte[] value = result.getValue(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("vector"));
                    byte[] deadlineBytes = result.getValue(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("deadline"));
                    if (deadlineBytes != null) {
                        String deadlineStr = Bytes.toString(deadlineBytes);
                        if (deadlineStr.compareTo(todayStr) < 0) {
                            Delete delete = new Delete(result.getRow());
                            table.delete(delete);
                        }
                        else {
                            if (value != null) {
                                Integer rowKey = Bytes.toInt(result.getRow());
                                Vector vector = deserializeVector(value);
                                jobVectors.add(new LocalJob(rowKey, vector));
                            }
                        }
                    }
                }
            }
            return jobVectors;
        }
    }

    public Vector updateVectorCV(Integer CVID) throws Exception{
        Connection connection = null;
        StringBuilder sb = new StringBuilder();
        try {
            connection = HikariDataSource.getConnection();
            stringifyCV(connection, sb, CVID);
            TextVectorizer textVectorizer = TextVectorizer.getInstance();
            Vector vector = textVectorizer.vectorize(sb.toString(), String.valueOf(CVID));
            saveCVtoHbase(CVID, vector);
            return vector;
        }
        finally {
            connection.close();
        }
    }

    public Vector readVectorCV(Integer CVID) throws Exception{
        try (org.apache.hadoop.hbase.client.Connection connection = ConnectionFactory.createConnection(config);
            Table table = connection.getTable(TableName.valueOf(TABLE_CV))) {
            Get get = new Get(Bytes.toBytes(String.valueOf(CVID)));
            get.addColumn(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("vector"));

            Result result = table.get(get);
            byte[] value = result.getValue(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("vector"));

            if (value != null) {
                return deserializeVector(value);
            } else {
                System.err.println("Không tìm thấy vector cho CVID = " + CVID);
            }
        }
        return null;
    }

    public void saveCVtoHbase(Integer CVID, Vector vector) throws Exception{
        try (org.apache.hadoop.hbase.client.Connection connection = ConnectionFactory.createConnection(config);
             Table table = connection.getTable(TableName.valueOf(TABLE_CV))) {

            String rowKey = String.valueOf(CVID);
            Put put = new Put(Bytes.toBytes(rowKey));

            byte[] vectorBytes = serializeVector(vector);
            put.addColumn(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("vector"), vectorBytes);
            table.put(put);
        }

    }

    public static byte[] serializeVector(Vector vector) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(vector);
        oos.close();
        return baos.toByteArray();
    }
    public static Vector deserializeVector(byte[] bytes) throws Exception {
        ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
        ObjectInputStream ois = new ObjectInputStream(bais);
        Vector vector = (Vector) ois.readObject();
        ois.close();
        return vector;
    }

    private void stringifyCV(Connection connection, StringBuilder sb, Integer CVID) throws Exception {
        System.out.println("CVID" + CVID);
        CVs cVs = readCV(ServerClient.CVFullInfo.newBuilder().setCVID(CVID).build(), connection);

        ArrayList<Certifications> certificationsArrayList = readCertificationList(ServerClient.CVFullInfo.newBuilder().setCVID(CVID).build(), connection);
        for(Certifications x : certificationsArrayList){
            sb.append(" ").append(x.getCertificationName());
        }

        ArrayList<Educations> educationsArrayList = readEducationList(ServerClient.CVFullInfo.newBuilder().setCVID(CVID).build(), connection);
        for(Educations x : educationsArrayList){
            sb.append(" ").append(x.getEduFields());
            sb.append(" ").append(x.getEduDescription());
        }

        ArrayList<Skills> skillsArrayList = readSkillsList(ServerClient.CVFullInfo.newBuilder().setCVID(CVID).build(), connection);
        for(Skills x : skillsArrayList){
            sb.append(" ").append(x.getSkillName());
        }

        ArrayList<WorkExperiences> workExperiencesArrayList = readWorkExperienceList(ServerClient.CVFullInfo.newBuilder().setCVID(CVID).build(), connection);
        for(WorkExperiences x : workExperiencesArrayList){
            sb.append(" ").append(x.getJobTitle());
            sb.append(" ").append(x.getJobDescription());
        }

        ArrayList<Projects> projectsArrayList = readProjectList(ServerClient.CVFullInfo.newBuilder().setCVID(CVID).build(), connection);
        for(Projects x : projectsArrayList){
            sb.append(" ").append(x.getProjectName());
            sb.append(" ").append(x.getPJRole());
            sb.append(" ").append(x.getPJDescription());
            sb.append(" ").append(x.getTechnology());
        }
    }


    public long HbaseupdateTimestamp(Integer CVID) throws Exception {
        try (org.apache.hadoop.hbase.client.Connection connection = ConnectionFactory.createConnection(config)) {
            Table table = connection.getTable(TableName.valueOf(TABLE_CV));

            String rowKey = String.valueOf(CVID);
            Get get = new Get(Bytes.toBytes(rowKey));
            get.addColumn(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("vector"));

            Result result = table.get(get);
            Cell cell = result.getColumnLatestCell(Bytes.toBytes(COLUMN_FAMILY), Bytes.toBytes("vector"));

            if (cell != null) {
                return cell.getTimestamp();
            } else {
                System.out.println("Vector column not found for this row.");
            }

            table.close();
        }
        return 0;
    }

    private Timestamp SQLupdateTimestamp(Integer CVID) throws SQLException {
        Connection connection = null;
        System.out.println("SQLupdateTimestamp");
        try {
            connection = HikariDataSource.getConnection();
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT `updatedAt` FROM `CVs` WHERE `CVs`.`CVID` = ?;");
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;
            try {
                preparedStatement =connection.prepareStatement(sb.toString());
                preparedStatement.setInt(1, CVID);
                resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    Timestamp updatedAt = resultSet.getTimestamp("updatedAt");
                    return updatedAt;
                } else {
                    return null;
                }
            }
            finally {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
            }
        } finally {
            if (connection != null) connection.close();
        }
    }


    public CVs readCV(ServerClient.CVFullInfo request, Connection connection) throws Exception {
        System.out.println("readCV");

        StringBuilder sb = new StringBuilder();
        sb.append("SELECT * FROM `CVs` WHERE `CVs`.`CVID` = ?;");
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            String sql = sb.toString();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, request.getCVID());
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                CVs cVs = new CVs();
                int cvID = resultSet.getInt("CVID");
                cVs.setCVID(cvID);

                int userID = resultSet.getInt("candidateID");
                if (userID == 0) throw new Exception("CV has an invalid userID");
                cVs.setCandidatesID(userID);

                String CVname = resultSet.getString("CVname");
                CVname = (CVname != null) ? CVname : "";
                cVs.setCVname(CVname);

                String imagePath = resultSet.getString("imagePath");
                imagePath = (imagePath != null) ? imagePath : "";
                cVs.setImagePath(imagePath);

                String jobPositions = resultSet.getString("jobPositions");
                jobPositions = (jobPositions != null) ? jobPositions : "";
                cVs.setJobPositions(jobPositions);

                String introduce = resultSet.getString("introduce");
                introduce = (introduce != null) ? introduce : "";
                cVs.setIntroduce(introduce);

                String email = resultSet.getString("email");
                email = (email != null) ? email : "";
                cVs.setEmail(email);

                String phoneNumber = resultSet.getString("phoneNumber");
                phoneNumber = (phoneNumber != null) ? phoneNumber : "";
                cVs.setPhoneNumber(phoneNumber);

                String socialMedia = resultSet.getString("socialMedia");
                socialMedia = (socialMedia != null) ? socialMedia : "";
                cVs.setSocialMedia(socialMedia);
                return cVs;
            } else {
                throw new Exception("CV not found");
            }
        } finally {
            if (resultSet != null) resultSet.close();
            if (preparedStatement != null) preparedStatement.close();
        }
    }

    public ArrayList<Certifications> readCertificationList(ServerClient.CVFullInfo request, Connection connection) throws Exception {
        System.out.println("readCertificationList");

        String query = "SELECT * FROM `Certifications` WHERE `Certifications`.`CVID` = ?;";
        ArrayList<Certifications> certificationsList = new ArrayList<>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(query);
            if (request.getCVID() == 0) throw new Exception("CVID is missing");
            preparedStatement.setInt(1, request.getCVID());
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Certifications certifications = new Certifications();
                certifications.setCVID(request.getCVID());

                Integer certificationID = resultSet.getInt("certificationID");
                if(certificationID <= 0) throw new Exception("CertificationID trả về không hợp lệ");
                certifications.setCertificationID(certificationID);

                String certificationName = resultSet.getString("certificationName");
                certifications.setCertificationName(certificationName != null ? certificationName : "");

                String provider = resultSet.getString("provider");
                certifications.setProvider(provider != null ? provider : "");

                Date providedDate = resultSet.getDate("providedDate");
                certifications.setProvidedDate(providedDate);

                certificationsList.add(certifications);
            }
            return certificationsList;
        } finally {
            if (resultSet != null) resultSet.close();
            if (preparedStatement != null) preparedStatement.close();
        }
    }

    public ArrayList<Educations> readEducationList(ServerClient.CVFullInfo request, Connection connection) throws Exception {
        System.out.println("readEducationList");

        String query = "SELECT * FROM `Educations` WHERE `Educations`.`CVID` = ?;";
        ArrayList<Educations> educationList = new ArrayList<>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(query);
            if (request.getCVID() == 0) throw new Exception("CVID is missing");
            preparedStatement.setInt(1, request.getCVID());
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Educations education = new Educations();
                education.setCVID(request.getCVID());

                Integer educationID = resultSet.getInt("educationID");
                if (educationID <= 0) throw new Exception("educationID returned is invalid");
                education.setEducationID(educationID);

                String degree = resultSet.getString("degree");
                education.setDegree(degree != null ? degree : "");

                String fieldOfStudy = resultSet.getString("EduFields");
                education.setEduFields(fieldOfStudy != null ? fieldOfStudy : "");

                String institution = resultSet.getString("EduDescription");
                education.setEduDescription(institution != null ? institution : "");

                Date startDate = resultSet.getDate("startDate");
                education.setStartDate(startDate);

                Date endDate = resultSet.getDate("endDate");
                education.setEndDate(endDate);

                educationList.add(education);
            }
            return educationList;
        } finally {
            if (resultSet != null) resultSet.close();
            if (preparedStatement != null) preparedStatement.close();
        }
    }

    public ArrayList<Skills> readSkillsList(ServerClient.CVFullInfo request, Connection connection) throws Exception {
        System.out.println("readSkillsList");

        String query = "SELECT * FROM `Skills` WHERE `Skills`.`CVID` = ?;";
        ArrayList<Skills> skillsList = new ArrayList<>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(query);
            if (request.getCVID() == 0) throw new Exception("CVID is missing");
            preparedStatement.setInt(1, request.getCVID());
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Skills skills = new Skills();
                skills.setCVID(request.getCVID());

                Integer skillID = resultSet.getInt("skillID");
                if (skillID <= 0) throw new Exception("SkillID returned is not valid");
                skills.setSkillID(skillID);

                String skillName = resultSet.getString("skillName");
                skills.setSkillName(skillName != null ? skillName : "");

                String proficiency = resultSet.getString("proficiency");
                if (proficiency != null) {
                    try {
                        Proficiency proficiencyEnum = Proficiency.valueOf(proficiency.toUpperCase());
                        skills.setProficiency(proficiencyEnum);
                    } catch (IllegalArgumentException e) {
                        throw new Exception("Invalid proficiency value returned");
                    }
                } else {
                    skills.setProficiency(Proficiency.BEGINNER);
                }

                skillsList.add(skills);
            }
            return skillsList;
        } finally {
            if (resultSet != null) resultSet.close();
            if (preparedStatement != null) preparedStatement.close();
        }
    }

    public ArrayList<WorkExperiences> readWorkExperienceList(ServerClient.CVFullInfo request, Connection connection) throws Exception {
        System.out.println("readWorkExperienceList");

        String query = "SELECT * FROM `WorkExperiences` WHERE `WorkExperiences`.`CVID` = ?;";
        ArrayList<WorkExperiences> workExperienceList = new ArrayList<>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(query);
            if (request.getCVID() == 0) throw new Exception("CVID is missing");
            preparedStatement.setInt(1, request.getCVID());
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                WorkExperiences workExperience = new WorkExperiences();
                workExperience.setCVID(request.getCVID());

                Integer workExperienceID = resultSet.getInt("workExperienceID");
                if (workExperienceID <= 0) throw new Exception("WorkExperienceID is invalid");
                workExperience.setWorkExperienceID(workExperienceID);

                String jobTitle = resultSet.getString("jobTitle");
                workExperience.setJobTitle(jobTitle != null ? jobTitle : "");

                String companyName = resultSet.getString("companyName");
                workExperience.setCompanyName(companyName != null ? companyName : "");

                Date startDate = resultSet.getDate("startDate");
                Date endDate = resultSet.getDate("endDate");
                workExperience.setStartDate(startDate);
                workExperience.setEndDate(endDate);

                workExperienceList.add(workExperience);
            }
            return workExperienceList;
        } finally {
            if (resultSet != null) resultSet.close();
            if (preparedStatement != null) preparedStatement.close();
        }
    }

    public ArrayList<Projects> readProjectList(ServerClient.CVFullInfo request, Connection connection) throws Exception {
        System.out.println("readProjectList");

        String query = "SELECT * FROM `Projects` WHERE `Projects`.`CVID` = ?;";
        ArrayList<Projects> skillsList = new ArrayList<>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            preparedStatement = connection.prepareStatement(query);
            if (request.getCVID() == 0) throw new Exception("CVID is missing");
            preparedStatement.setInt(1, request.getCVID());
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Projects projects = new Projects();
                projects.setCVID(request.getCVID());

                Integer projectID = resultSet.getInt("projectID");
                if (projectID <= 0) throw new Exception("projectID returned is not valid");
                projects.setProjectID(projectID);

                String projectName = resultSet.getString("projectName");
                projects.setProjectName(projectName != null ? projectName : "");

                String PJRole = resultSet.getString("PJRole");
                projects.setPJRole(PJRole != null ? PJRole : "");

                String technology = resultSet.getString("technology");
                projects.setTechnology(technology != null ? technology : "");

                String PJDescription = resultSet.getString("PJDescription");
                projects.setPJDescription(PJDescription != null ? PJDescription : "");

                Date startDate = resultSet.getDate("startDate");
                Date endDate = resultSet.getDate("endDate");
                projects.setStartDate(startDate);
                projects.setEndDate(endDate);

                skillsList.add(projects);
            }
            return skillsList;
        } finally {
            if (resultSet != null) resultSet.close();
            if (preparedStatement != null) preparedStatement.close();
        }
    }

    public class LocalJob {
        private Integer jobID;
        private Vector vector;

        public LocalJob(Integer jobID, Vector vector) {
            this.jobID = jobID;
            this.vector = vector;
        }

        public Integer getJobID() { return jobID; }
        public Vector getVector() { return vector; }
    }
}
