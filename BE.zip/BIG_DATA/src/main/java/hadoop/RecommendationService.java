package hadoop;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.ml.linalg.VectorUDT;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.types.DataTypes;
import scala.collection.mutable.Seq;

import static org.apache.spark.sql.functions.*;

import java.util.Objects;
import java.util.stream.Collectors;

import java.util.List;

public class RecommendationService {
    private static RecommendationService instance;
    private final SparkSession spark;

    private RecommendationService() {
        spark = SparkSession.builder()
                .appName("Recommendation Service")
                .master("local[*]")
                .config("spark.hadoop.fs.defaultFS", "hdfs://master1:9000")
                .getOrCreate();
    }

    public static RecommendationService getInstance() {
        if (instance == null) {
            synchronized (RecommendationService.class) {
                if (instance == null) {
                    instance = new RecommendationService();
                }
            }
        }
        return instance;
    }

    public List<Integer> findTop5JobsForCV(Vector cvVector, String parquetPath) {
        System.out.println("findTop5JobsForCV");

        Dataset<Row> jobVectorsRaw = spark.read()
                .parquet("hdfs://master1:9000/user/WBAC/user/jobs.parquet");

        System.out.println("read Parquet");

        spark.udf().register("toVector", (UDF1<Seq<Double>, Vector>) (Seq<Double> vectorSeq) -> {
            double[] values = new double[vectorSeq.size()];
            for (int i = 0; i < vectorSeq.size(); i++) {
                values[i] = vectorSeq.apply(i);
            }
            return Vectors.dense(values);
        }, new VectorUDT());

        Dataset<Row> jobVectors = jobVectorsRaw.withColumn("features",
                callUDF("toVector", col("vector")));

        System.out.println("calc");
        Broadcast<Vector> cvBroadcast = JavaSparkContext.fromSparkContext(spark.sparkContext()).broadcast(cvVector);

        spark.udf().register("cosineSimWithCV", (UDF1<Vector, Double>) (Vector v2) -> {
            Vector v1 = cvBroadcast.value();
            double dot = 0.0, norm1 = 0.0, norm2 = 0.0;

            for (int i = 0; i < v1.size(); i++) {
                double val1 = v1.apply(i);
                double val2 = v2.apply(i);
                dot += val1 * val2;
                norm1 += val1 * val1;
                norm2 += val2 * val2;
            }

            if (norm1 == 0.0 || norm2 == 0.0) {
                return 0.0; // or Double.NaN, depending on your preference
            } else {
                return dot / (Math.sqrt(norm1) * Math.sqrt(norm2));
            }
        }, DataTypes.DoubleType);


        Dataset<Row> scoredJobs = jobVectors.withColumn("similarity",
                callUDF("cosineSimWithCV", col("features")));
        List<Row> top5 = scoredJobs.orderBy(col("similarity").desc()).limit(5).collectAsList();
        scoredJobs.filter("similarity IS NOT NULL AND NOT isnan(similarity)").show();

        List<Integer> jobIDs = top5.stream()
                .map(row -> row.getAs("jobID"))
                .filter(Objects::nonNull)
                .map(Object::toString)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(Integer::parseInt)
                .collect(Collectors.toList());

        return jobIDs;
    }
    public void stop() {
        spark.stop();
    }
}

